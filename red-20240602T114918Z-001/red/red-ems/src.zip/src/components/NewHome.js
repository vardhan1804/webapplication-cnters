import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteUser, loadUsers } from '../actions/actions';
import { useNavigate } from 'react-router-dom';
//import LiveSearchFilter from './LiveSearchFilter';
import 'bootstrap/dist/css/bootstrap.min.css';

const NewHome = () => {

    let history = useNavigate();
    let dispatch = useDispatch();

    const { users } = useSelector(state => state.data)
    useEffect(() => {
        dispatch(loadUsers());
    }, [dispatch]);

    const handleDelete = (id) => {


        if (window.confirm("are u sure ,u want to delete?")) {
            dispatch(deleteUser(id))
        }
    };
    return (

        <div>
            <nav class="navbar navbar-light bg-light" >
                <h1 style={{ fontSize: 25 }}> EMS <i class="bi bi-people-fill"></i></h1>
                <h4 style={{ fontSize: 20, position: 'absolute', width: 1200, color: 'black' }}> EMS Portal</h4>

            </nav>

            <div >
                <button type="button" class="btn btn-primary" style={{ marginTop: 50, marginLeft: 900, align: "right" }} onClick={() => history("/addUser")}>Add User</button>
            </div>
            <br />
            <table class="table responsive-align-middle mb-0 bg-white">
                <thead class="thead-dark bg-black text-white">
                    <tr>
                        <th scope="col">Id</th>

                        <th scope="col">Name</th>
                        <th scope="col">Age</th>
                        <th scope="col">Salary</th>
                        <th scope="col">Address</th>
                        <th scope="col">role</th>
                        <th scope="col">Action</th>


                    </tr>
                </thead>
                <tbody>
                    {users && users.map((user) => (
                        <tr>
                            <th scope="row">{user.id}</th>
                            <td>      {user.name}
                            </td>
                            <td>{user.age}</td>
                            <td>{user.salary}</td>
                            <td>{user.address}</td>
                            <td>{user.role}</td>
                            <td>
                                <div class="btn-group" role="group" aria-label="Basic example">
                                    <button type="button" class="btn btn-danger" style={{ marginRight: 5 }} onClick={() => handleDelete(user.id)}>Delete</button>
                                    <button type="button" class="btn btn-dark" onClick={() => history(`/editUser/${user.id}`)}>Edit</button>
                                </div>
                            </td>


                        </tr>
                    ))}
                </tbody>
            </table>

        </div>
    )
}

export default NewHome;