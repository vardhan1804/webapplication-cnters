import React, { Component } from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { addUser } from '../actions/actions';
//import { useDispatch } from 'react-redux';
import { connect } from 'react-redux';

import 'bootstrap/dist/css/bootstrap.min.css';  

class AddC extends Component {
    constructor(props){
        super(props);


        this.onChangeName= this.onChangeName.bind(this);
        this.onChangeSalary= this.onChangeSalary.bind(this);
        this.onChangeAge= this.onChangeAge.bind(this);
        this.onChangeAddress= this.onChangeAddress.bind(this);
        this.onChangeRole= this.onChangeRole.bind(this);

        this.handleSubmit = this.handleSubmit.bind(this);
this.state={
        name: "",
        age: "",
        salary: "",
        role: "",
        address: "",
        error:false
    };
}
 onChangeName(e){
    this.setState({
      name: e.target.value,
    });
  }
  
  onChangeSalary(e){
    this.setState({
      salary: e.target.value,
    });
  }
  onChangeAge(e){
    this.setState({
      age: e.target.value,
    });
  }
  
  onChangeAddress(e){
    this.setState({
      address: e.target.value,
    });
  }
  onChangeRole(e){
    this.setState({
      role: e.target.value,
    });
  }
  
    
     handleSubmit (){
        const { name, salary, age, address, role } = this.state;
      
        // if (!name || !email || !contact || !address) {
        if (!this.state.name || !this.state.age || !this.state.salary || !this.state.role || !this.state.address) {

            this.setState={
                name: "",
                age: "",
                salary: "",
                role: "",
                address: "",
                error:"true"
            };       
         } else {
            this.state(name, salary, age, address, role)
          .then(data => {
            this.setState({
              id: data.id,
              name: data.name,
              salary: data.salary,
              age: data.age,
              address: data.address,
              role: data.role,
      
              error: false,
      
            });
            console.log(data);
            window.locate.replace('/');


        })
        
    }
}
render(){

    return (
        <div>
            <Button style={{ marginTop: 80 }} variant="contained" color="secondary" onClick={() => window.locate.replace('/')

}>Home</Button>
            <br />
            <br />
            <br />
            <br />
            <br />

            <h2 style={{ paddingTop: 80}}> AddUser </h2>
            {this.state.error && <h3 style={{ color: "red" }}> {this.state.error} </h3>}


            <form onSubmit={this.handleSubmit}>
                <TextField id="standard-basic" label="Name" variant="standard" value={this.state.name} name="name" type="text" onChange={this.onChangeName} />
                
                <br />
                <TextField id="standard-basic" label="Age" variant="standard" value={this.state.age} name="age" type="number" onChange={this.onChangeAge} />
                <br />
                <TextField id="standard-basic" label="Salary" variant="standard" value={this.state.salary} name="salary" type="number" onChange={this.onChangeSalary} />

                <br />
                <TextField id="standard-basic" label="Address" variant="standard" value={this.state.address} name="address" type="text" onChange={this.onChangeAddress} />

                <br />
                <TextField id="standard-basic" label="Role" variant="standard" value={this.state.role} name="role" type="text" onChange={this.onChangeRole} />

                <br />
                <br />

                <Button style={{ marginRight: "5px" }} variant="contained" color="primary" type="submit" >Submit</Button>


            </form>


        </div>
    )
}
}
export default connect(null, { addUser })(AddC);