import React, { useState, useEffect } from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { GetSingleUser, updateUser } from '../actions/actions';
import { useDispatch, useSelector } from 'react-redux';

import { useNavigate, useParams } from 'react-router-dom';
const EditUser = () => {
    let dispatch = useDispatch();
    let { id } = useParams();
    const { user } = useSelector((state) => state.data);
    const [state, setState] = useState({
        name: "",
        age: "",
        salary: "",
        role: "",
        address: "",
        // email: "",
        // contact: "",

        // address: ""
    });
    const [error, setError] = useState("");
    let navigate = useNavigate();

    //const { name, email, contact, address } = state;
    const { name, age, salary, role, address } = state;

    useEffect(() => {
        dispatch(GetSingleUser(id))
    }, [dispatch]);

    useEffect(() => {
        if (user) {
            setState({ ...user });
        }
    }, [user]);
    const handleInputChange = (e) => {
        let { name, value } = e.target;
        setState({
            ...state,
            [name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // if (!name || !email || !contact || !address) {
        if (!name || !age || !salary || !role || !address) {

            setError("please input all the required fieds");
        } else {
            dispatch(updateUser(state, id));
            navigate("/");
            setError("");
        }
    };
    return (
        <div>
            <Button style={{ marginTop: 10 }} variant="contained" color="secondary" onClick={() => navigate("/")}>Home</Button>
            <br />

            <h2>Edit User </h2>
            {error && <h3 style={{ color: "red" }}> {error} </h3>}

            <form onSubmit={handleSubmit}>
                <TextField id="standard-basic" label="Name" variant="standard" value={name} name="name" type="text" onChange={handleInputChange} />
                {/* <br />
                <TextField id="standard-basic" label="Email" variant="standard" value={email} type="text" name="email" onChange={handleInputChange} />
                <br />

                <TextField id="standard-basic" label="Contact" variant="standard" value={contact} type="number" name="contact" onChange={handleInputChange} />
                <br />

                <TextField id="standard-basic" label="Address" variant="standard" value={address} type="text" name="address" onChange={handleInputChange} />
                <br /> */}
                <br />
                <TextField id="standard-basic" label="Age" variant="standard" value={age} name="age" type="number" onChange={handleInputChange} />
                <br />
                <TextField id="standard-basic" label="Salary" variant="standard" value={salary} name="salary" type="number" onChange={handleInputChange} />

                <br />
                <br />
                <TextField id="standard-basic" label="Address" variant="standard" value={address} name="address" type="text" onChange={handleInputChange} />

                <br />
                <br />
                <TextField id="standard-basic" label="Role" variant="standard" value={role} name="role" type="text" onChange={handleInputChange} />

                <br />
                <br />

                <Button style={{ marginRight: "5px" }} variant="contained" color="primary" type="submit" >Submit</Button>


            </form>


        </div>
    )
}



export default EditUser;