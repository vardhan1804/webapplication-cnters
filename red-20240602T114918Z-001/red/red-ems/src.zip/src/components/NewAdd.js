import React, { useState } from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { addUser } from '../actions/actions';
import { useDispatch } from 'react-redux';

import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';  

const NewAdd = () => {
    let dispatch = useDispatch();

    const [state, setState] = useState({
        name: "",
        age: "",
        salary: "",
        role: "",
        address: "",
        // email: "",
        // contact: "",

        // address: ""
    });
    const [error, setError] = useState("");
    let navigate = useNavigate();

    //const { name, email, contact, address } = state;
    const { name, age, salary, role, address } = state;

    const handleInputChange = (e) => {
        let { name, value } = e.target;
        setState({
            ...state,
            [name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // if (!name || !email || !contact || !address) {
        if (!name || !age || !salary || !role || !address) {

            setError("please input all the required fieds");
        } else {
            dispatch(addUser(state));
            navigate("/");
            setError("");
        }
    };
    return (
        <div>
            <Button style={{ marginTop: 80 }} variant="contained" color="secondary" onClick={() => navigate("/")}>Home</Button>
            <br />
            <br />
            <br />
            <br />
            <br />

            <h2 style={{ paddingTop: 80}}> AddUser </h2>
            {error && <h3 style={{ color: "red" }}> {error} </h3>}


            <form onSubmit={handleSubmit}>
                <TextField id="standard-basic" label="Name" variant="standard" value={name} name="name" type="text" onChange={handleInputChange} />
                {/* <br />
                <TextField id="standard-basic" label="Email" variant="standard" value={email} type="text" name="email" onChange={handleInputChange} />
                <br />

                <TextField id="standard-basic" label="Contact" variant="standard" value={contact} type="number" name="contact" onChange={handleInputChange} />
                <br />

                <TextField id="standard-basic" label="Address" variant="standard" value={address} type="text" name="address" onChange={handleInputChange} />
    <br /> */}
                <br />
                <TextField id="standard-basic" label="Age" variant="standard" value={age} name="age" type="number" onChange={handleInputChange} />
                <br />
                <TextField id="standard-basic" label="Salary" variant="standard" value={salary} name="salary" type="number" onChange={handleInputChange} />

                <br />
                <TextField id="standard-basic" label="Address" variant="standard" value={address} name="address" type="text" onChange={handleInputChange} />

                <br />
                <TextField id="standard-basic" label="Role" variant="standard" value={role} name="role" type="text" onChange={handleInputChange} />

                <br />
                <br />

                <Button style={{ marginRight: "5px" }} variant="contained" color="primary" type="submit" >Submit</Button>


            </form>


        </div>
    )
}

export default NewAdd;