
import './App.css';
import { Routes, Route } from 'react-router-dom';
//import AddC from './components/AddC';
import AddUser from './components/AddUser';
import EditUser from './components/EditUser';
import NewHome from './components/NewHome';
import LiveSearchFilter from './components/LiveSearchFilter';
//import Home from './components/Home';
function App() {
  return (
    <div className="App">
      <Routes>
        <Route exact path="/s" element={<LiveSearchFilter/>}/>
        <Route exact path="/" element={<NewHome />} />
        <Route exact path="/addUser" element={<AddUser />} />
        <Route exact path="/editUser/:id" element={<EditUser />} />

      </Routes>
    </div>
  );
}

export default App;
